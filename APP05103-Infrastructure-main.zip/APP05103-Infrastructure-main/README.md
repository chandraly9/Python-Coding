# A10Infrastructure



## Overview
The repo manages A10 VIP infrastructure via Terraform. VIPs, Service Groups, Servers, and other configuration components for A10 load-balancers are defined in HCL resource files. Changes to these resources are approved through the merge request process and deployed to load-balancers automatically by CICD pipeline jobs.

## Process

### Clone Repo
```
git clone git@gitssh.jwn.app:TM01026/APP05103-Infrastructure.git
```

### Checkout Feature Branch
```
git checkout <branch-name>
```

### Update VIP or Service Group Resources
Make updates to HCL or YAML files based on your desired outcome. Here is an example of disabling a server within an existing Service Group:
```diff
diff --git a/terraform/nonprod/example.nordstrom.com/service_group/main.tf b/terraform/nonprod/example.nordstrom.com/service_group/main.tf
index cda156c..f958c0f 100644
--- a/terraform/nonprod/example.nordstrom.com/service_group/main.tf
+++ b/terraform/nonprod/example.nordstrom.com/service_group/main.tf
@@ -32,10 +32,10 @@ resource "thunder_service_group" "example_nordstrom_com_service_group" {
     name = thunder_server.example_server_01.name
     port = 80
   }
-  member_list {
-    name = thunder_server.example_server_02.name
-    port = 80
-  }
+  # member_list {
+  #   name = thunder_server.example_server_02.name
+  #   port = 80
+  # }
 }
```

### Raise Merge Request
```
git commit -am "Description of change"
git push origin <branch-name>
```
* Changes to VIP-level resources will require approval from NetSec
* Changes to ServiceGroup-level resources can be approved by anyone with access to this repo

### Deploy
Once your MR is approved, the pipeline will deploy using Gitlab runners in NSK. [Here](https://git.jwn.app/TM01026/APP05103-Infrastructure/-/jobs/22631152) is an example of a full VIP, Service Group, and server deployment.

## Common Change Examples
* [Temporarily disable server in service group](https://git.jwn.app/TM01026/APP05103-Infrastructure/-/merge_requests/12)
* [Change IP of existing VIP](https://git.jwn.app/TM01026/APP05103-Infrastructure/-/merge_requests/11)

# Stolen from the Edge Traffic Team

echo "\033[34;1m ########## Starting DEPLOY stage ##########\033[0;m"

# Setup AWS Creds
creds-helper -aws

# Enter TF Directory
cd $1

# Runs TF init, plan, and show - then checks output
terraform init || exit 1
terraform plan -lock-timeout=240s -out="plan" > check || exit 1
terraform show "plan" -no-color > viewplan

if [ $? -ne 0 ];
then
    # Prints a warning if error was thrown
    cat check
else
    # Succeeds checks
    cat check
    terraform apply -lock-timeout=240s -input=false "plan" || exit 1
    echo "\033[32;1mDeploy stage for $CI_JOB_NAME Succeeded!\033[0;m"
fi
